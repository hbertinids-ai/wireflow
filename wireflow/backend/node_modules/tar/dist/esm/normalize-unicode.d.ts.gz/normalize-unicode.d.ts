export declare const normalizeUnicode: (s: string) => string;
//# sourceMappingURL=normalize-unicode.d.ts.map