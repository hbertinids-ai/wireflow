export declare const stripTrailingSlashes: (str: string) => string;
//# sourceMappingURL=strip-trailing-slashes.d.ts.map