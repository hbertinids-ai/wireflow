/// <reference types="node" resolution-mode="require"/>
/// <reference types="node" resolution-mode="require"/>
export declare const encode: (num: number, buf: Buffer) => Buffer;
export declare const parse: (buf: Buffer) => number;
//# sourceMappingURL=large-numbers.d.ts.map