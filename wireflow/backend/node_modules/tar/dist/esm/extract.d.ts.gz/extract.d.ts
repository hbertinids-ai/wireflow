import { Unpack, UnpackSync } from './unpack.js';
export declare const extract: import("./make-command.js").TarCommand<Unpack, UnpackSync>;
//# sourceMappingURL=extract.d.ts.map