export declare const update: import("./make-command.js").TarCommand<never, never>;
//# sourceMappingURL=update.d.ts.map