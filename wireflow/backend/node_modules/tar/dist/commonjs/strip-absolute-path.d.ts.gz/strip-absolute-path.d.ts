export declare const stripAbsolutePath: (path: string) => string[];
//# sourceMappingURL=strip-absolute-path.d.ts.map