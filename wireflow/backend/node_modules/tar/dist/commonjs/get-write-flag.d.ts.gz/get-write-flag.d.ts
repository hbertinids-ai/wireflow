export declare const getWriteFlag: (() => string) | ((size: number) => number | "w");
//# sourceMappingURL=get-write-flag.d.ts.map