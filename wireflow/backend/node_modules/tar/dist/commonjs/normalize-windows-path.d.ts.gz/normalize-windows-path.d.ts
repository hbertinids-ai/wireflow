export declare const normalizeWindowsPath: (p: string) => string;
//# sourceMappingURL=normalize-windows-path.d.ts.map