/// <reference types="node" />
/// <reference types="node" />
export declare const encode: (num: number, buf: Buffer) => Buffer;
export declare const parse: (buf: Buffer) => number;
//# sourceMappingURL=large-numbers.d.ts.map