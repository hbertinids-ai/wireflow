export declare const replace: import("./make-command.js").TarCommand<never, never>;
//# sourceMappingURL=replace.d.ts.map