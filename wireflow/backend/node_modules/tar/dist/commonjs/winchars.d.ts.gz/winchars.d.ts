export declare const encode: (s: string) => string;
export declare const decode: (s: string) => string;
//# sourceMappingURL=winchars.d.ts.map