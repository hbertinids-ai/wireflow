export declare const modeFix: (mode: number, isDir: boolean, portable: boolean) => number;
//# sourceMappingURL=mode-fix.d.ts.map