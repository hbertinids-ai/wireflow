import { Pack, PackSync } from './pack.js';
export declare const create: import("./make-command.js").TarCommand<Pack, PackSync>;
//# sourceMappingURL=create.d.ts.map