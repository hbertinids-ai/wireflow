declare function setDunderProto<P extends null | object>(target: {}, proto: P): P;

declare const x: false | typeof setDunderProto;

export = x;