'use strict';

/** @type {import('./functionCall')} */
module.exports = Function.prototype.call;
