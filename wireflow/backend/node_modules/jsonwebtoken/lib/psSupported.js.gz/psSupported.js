var semver = require('semver');

module.exports = semver.satisfies(process.version, '^6.12.0 || >=8.0.0');
