const semver = require('semver');

module.exports = semver.satisfies(process.version, '>=15.7.0');
