export { fromFetch } from '../internal/observable/dom/fetch';
//# sourceMappingURL=index.js.map