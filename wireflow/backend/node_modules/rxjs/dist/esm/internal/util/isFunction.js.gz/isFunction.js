export function isFunction(value) {
    return typeof value === 'function';
}
//# sourceMappingURL=isFunction.js.map