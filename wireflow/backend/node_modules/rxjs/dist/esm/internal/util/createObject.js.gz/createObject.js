export function createObject(keys, values) {
    return keys.reduce((result, key, i) => ((result[key] = values[i]), result), {});
}
//# sourceMappingURL=createObject.js.map