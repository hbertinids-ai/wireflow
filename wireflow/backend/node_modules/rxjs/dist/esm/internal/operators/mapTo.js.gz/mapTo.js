import { map } from './map';
export function mapTo(value) {
    return map(() => value);
}
//# sourceMappingURL=mapTo.js.map