import { filter } from './filter';
export function skip(count) {
    return filter((_, index) => count <= index);
}
//# sourceMappingURL=skip.js.map