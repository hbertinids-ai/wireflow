import { combineLatest } from '../observable/combineLatest';
import { joinAllInternals } from './joinAllInternals';
export function combineLatestAll(project) {
    return joinAllInternals(combineLatest, project);
}
//# sourceMappingURL=combineLatestAll.js.map