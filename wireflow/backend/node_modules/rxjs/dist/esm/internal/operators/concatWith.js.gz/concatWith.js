import { concat } from './concat';
export function concatWith(...otherSources) {
    return concat(...otherSources);
}
//# sourceMappingURL=concatWith.js.map