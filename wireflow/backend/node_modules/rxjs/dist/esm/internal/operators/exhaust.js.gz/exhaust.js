import { exhaustAll } from './exhaustAll';
export const exhaust = exhaustAll;
//# sourceMappingURL=exhaust.js.map