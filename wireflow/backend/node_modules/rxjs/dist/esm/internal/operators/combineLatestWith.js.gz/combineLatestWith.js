import { combineLatest } from './combineLatest';
export function combineLatestWith(...otherSources) {
    return combineLatest(...otherSources);
}
//# sourceMappingURL=combineLatestWith.js.map