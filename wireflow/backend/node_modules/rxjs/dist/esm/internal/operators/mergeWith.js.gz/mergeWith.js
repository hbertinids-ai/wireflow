import { merge } from './merge';
export function mergeWith(...otherSources) {
    return merge(...otherSources);
}
//# sourceMappingURL=mergeWith.js.map