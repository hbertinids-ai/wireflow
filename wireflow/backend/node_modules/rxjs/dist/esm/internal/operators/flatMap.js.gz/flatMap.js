import { mergeMap } from './mergeMap';
export const flatMap = mergeMap;
//# sourceMappingURL=flatMap.js.map