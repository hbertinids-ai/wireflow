import { zip } from './zip';
export function zipWith(...otherInputs) {
    return zip(...otherInputs);
}
//# sourceMappingURL=zipWith.js.map