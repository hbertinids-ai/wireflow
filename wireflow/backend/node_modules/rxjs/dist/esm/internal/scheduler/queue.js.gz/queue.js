import { QueueAction } from './QueueAction';
import { QueueScheduler } from './QueueScheduler';
export const queueScheduler = new QueueScheduler(QueueAction);
export const queue = queueScheduler;
//# sourceMappingURL=queue.js.map