"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TestScheduler = void 0;
var TestScheduler_1 = require("../internal/testing/TestScheduler");
Object.defineProperty(exports, "TestScheduler", { enumerable: true, get: function () { return TestScheduler_1.TestScheduler; } });
//# sourceMappingURL=index.js.map