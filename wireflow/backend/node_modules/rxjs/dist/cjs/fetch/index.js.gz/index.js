"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.fromFetch = void 0;
var fetch_1 = require("../internal/observable/dom/fetch");
Object.defineProperty(exports, "fromFetch", { enumerable: true, get: function () { return fetch_1.fromFetch; } });
//# sourceMappingURL=index.js.map