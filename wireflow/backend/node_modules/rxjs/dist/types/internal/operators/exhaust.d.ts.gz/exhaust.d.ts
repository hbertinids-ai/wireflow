import { exhaustAll } from './exhaustAll';
/**
 * @deprecated Renamed to {@link exhaustAll}. Will be removed in v8.
 */
export declare const exhaust: typeof exhaustAll;
//# sourceMappingURL=exhaust.d.ts.map