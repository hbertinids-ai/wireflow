import { mergeMap } from './mergeMap';
/**
 * @deprecated Renamed to {@link mergeMap}. Will be removed in v8.
 */
export declare const flatMap: typeof mergeMap;
//# sourceMappingURL=flatMap.d.ts.map