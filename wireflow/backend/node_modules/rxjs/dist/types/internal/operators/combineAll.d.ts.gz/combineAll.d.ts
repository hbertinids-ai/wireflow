import { combineLatestAll } from './combineLatestAll';
/**
 * @deprecated Renamed to {@link combineLatestAll}. Will be removed in v8.
 */
export declare const combineAll: typeof combineLatestAll;
//# sourceMappingURL=combineAll.d.ts.map