import { InteropObservable, SchedulerLike } from '../types';
export declare function scheduleObservable<T>(input: InteropObservable<T>, scheduler: SchedulerLike): import("../Observable").Observable<T>;
//# sourceMappingURL=scheduleObservable.d.ts.map