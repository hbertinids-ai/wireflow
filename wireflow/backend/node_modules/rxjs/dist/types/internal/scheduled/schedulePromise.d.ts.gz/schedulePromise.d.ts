import { SchedulerLike } from '../types';
export declare function schedulePromise<T>(input: PromiseLike<T>, scheduler: SchedulerLike): import("../Observable").Observable<T>;
//# sourceMappingURL=schedulePromise.d.ts.map