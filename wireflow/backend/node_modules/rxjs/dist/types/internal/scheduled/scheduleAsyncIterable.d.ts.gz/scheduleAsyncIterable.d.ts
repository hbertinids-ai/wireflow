import { SchedulerLike } from '../types';
import { Observable } from '../Observable';
export declare function scheduleAsyncIterable<T>(input: AsyncIterable<T>, scheduler: SchedulerLike): Observable<T>;
//# sourceMappingURL=scheduleAsyncIterable.d.ts.map