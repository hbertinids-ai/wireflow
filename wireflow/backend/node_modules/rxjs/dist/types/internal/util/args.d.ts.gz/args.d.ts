import { SchedulerLike } from '../types';
export declare function popResultSelector(args: any[]): ((...args: unknown[]) => unknown) | undefined;
export declare function popScheduler(args: any[]): SchedulerLike | undefined;
export declare function popNumber(args: any[], defaultValue: number): number;
//# sourceMappingURL=args.d.ts.map