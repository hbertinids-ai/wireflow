/**
 * Returns true if the object is a function.
 * @param value The value to check
 */
export declare function isFunction(value: any): value is (...args: any[]) => any;
//# sourceMappingURL=isFunction.d.ts.map