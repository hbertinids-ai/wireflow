export declare function applyMixins(derivedCtor: any, baseCtors: any[]): void;
//# sourceMappingURL=applyMixins.d.ts.map