export {};
//# sourceMappingURL=workarounds.d.ts.map