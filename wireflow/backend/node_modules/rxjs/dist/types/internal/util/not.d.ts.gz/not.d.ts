export declare function not<T>(pred: (value: T, index: number) => boolean, thisArg: any): (value: T, index: number) => boolean;
//# sourceMappingURL=not.d.ts.map