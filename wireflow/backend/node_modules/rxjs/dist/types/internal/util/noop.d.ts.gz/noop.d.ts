export declare function noop(): void;
//# sourceMappingURL=noop.d.ts.map