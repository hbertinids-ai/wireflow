export declare function isAsyncIterable<T>(obj: any): obj is AsyncIterable<T>;
//# sourceMappingURL=isAsyncIterable.d.ts.map