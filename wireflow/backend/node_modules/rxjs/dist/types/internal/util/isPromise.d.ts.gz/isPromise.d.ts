/**
 * Tests to see if the object is "thennable".
 * @param value the object to test
 */
export declare function isPromise(value: any): value is PromiseLike<any>;
//# sourceMappingURL=isPromise.d.ts.map