export declare function createObject(keys: string[], values: any[]): any;
//# sourceMappingURL=createObject.d.ts.map