import { SchedulerLike } from '../types';
export declare function isScheduler(value: any): value is SchedulerLike;
//# sourceMappingURL=isScheduler.d.ts.map