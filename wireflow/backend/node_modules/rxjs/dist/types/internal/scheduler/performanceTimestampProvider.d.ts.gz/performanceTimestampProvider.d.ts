import { TimestampProvider } from '../types';
interface PerformanceTimestampProvider extends TimestampProvider {
    delegate: TimestampProvider | undefined;
}
export declare const performanceTimestampProvider: PerformanceTimestampProvider;
export {};
//# sourceMappingURL=performanceTimestampProvider.d.ts.map