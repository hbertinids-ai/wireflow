export declare type TimerHandle = number | ReturnType<typeof setTimeout>;
//# sourceMappingURL=timerHandle.d.ts.map