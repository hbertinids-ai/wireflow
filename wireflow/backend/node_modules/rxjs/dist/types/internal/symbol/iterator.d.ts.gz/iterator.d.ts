export declare function getSymbolIterator(): symbol;
export declare const iterator: symbol;
//# sourceMappingURL=iterator.d.ts.map