export { webSocket as webSocket } from '../internal/observable/dom/webSocket';
export { WebSocketSubject, WebSocketSubjectConfig } from '../internal/observable/dom/WebSocketSubject';
//# sourceMappingURL=index.d.ts.map