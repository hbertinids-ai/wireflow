import { exhaustAll } from './exhaustAll';
export var exhaust = exhaustAll;
//# sourceMappingURL=exhaust.js.map