import { exhaustMap } from './exhaustMap';
import { identity } from '../util/identity';
export function exhaustAll() {
    return exhaustMap(identity);
}
//# sourceMappingURL=exhaustAll.js.map