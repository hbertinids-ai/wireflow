import { map } from './map';
export function mapTo(value) {
    return map(function () { return value; });
}
//# sourceMappingURL=mapTo.js.map