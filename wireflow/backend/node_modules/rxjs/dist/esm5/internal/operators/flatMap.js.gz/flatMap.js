import { mergeMap } from './mergeMap';
export var flatMap = mergeMap;
//# sourceMappingURL=flatMap.js.map