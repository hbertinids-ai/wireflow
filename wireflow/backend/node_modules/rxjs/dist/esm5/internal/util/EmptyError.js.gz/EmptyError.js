import { createErrorClass } from './createErrorClass';
export var EmptyError = createErrorClass(function (_super) {
    return function EmptyErrorImpl() {
        _super(this);
        this.name = 'EmptyError';
        this.message = 'no elements in sequence';
    };
});
//# sourceMappingURL=EmptyError.js.map