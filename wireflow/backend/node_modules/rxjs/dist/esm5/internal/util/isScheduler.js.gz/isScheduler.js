import { isFunction } from './isFunction';
export function isScheduler(value) {
    return value && isFunction(value.schedule);
}
//# sourceMappingURL=isScheduler.js.map