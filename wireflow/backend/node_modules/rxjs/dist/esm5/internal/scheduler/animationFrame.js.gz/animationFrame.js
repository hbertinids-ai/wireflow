import { AnimationFrameAction } from './AnimationFrameAction';
import { AnimationFrameScheduler } from './AnimationFrameScheduler';
export var animationFrameScheduler = new AnimationFrameScheduler(AnimationFrameAction);
export var animationFrame = animationFrameScheduler;
//# sourceMappingURL=animationFrame.js.map