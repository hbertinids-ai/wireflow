import { __extends } from "tslib";
import { AsyncScheduler } from './AsyncScheduler';
var QueueScheduler = (function (_super) {
    __extends(QueueScheduler, _super);
    function QueueScheduler() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return QueueScheduler;
}(AsyncScheduler));
export { QueueScheduler };
//# sourceMappingURL=QueueScheduler.js.map