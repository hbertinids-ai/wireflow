import { AsyncAction } from './AsyncAction';
import { AsyncScheduler } from './AsyncScheduler';
export var asyncScheduler = new AsyncScheduler(AsyncAction);
export var async = asyncScheduler;
//# sourceMappingURL=async.js.map