import { QueueAction } from './QueueAction';
import { QueueScheduler } from './QueueScheduler';
export var queueScheduler = new QueueScheduler(QueueAction);
export var queue = queueScheduler;
//# sourceMappingURL=queue.js.map