import { AsapAction } from './AsapAction';
import { AsapScheduler } from './AsapScheduler';
export var asapScheduler = new AsapScheduler(AsapAction);
export var asap = asapScheduler;
//# sourceMappingURL=asap.js.map