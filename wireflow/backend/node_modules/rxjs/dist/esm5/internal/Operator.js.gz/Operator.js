export {};
//# sourceMappingURL=Operator.js.map