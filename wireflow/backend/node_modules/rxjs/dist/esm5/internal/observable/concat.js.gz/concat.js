import { concatAll } from '../operators/concatAll';
import { popScheduler } from '../util/args';
import { from } from './from';
export function concat() {
    var args = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        args[_i] = arguments[_i];
    }
    return concatAll()(from(args, popScheduler(args)));
}
//# sourceMappingURL=concat.js.map