import { exhaustAll } from './exhaustAll';

/**
 * @deprecated Renamed to {@link exhaustAll}. Will be removed in v8.
 */
export const exhaust = exhaustAll;
