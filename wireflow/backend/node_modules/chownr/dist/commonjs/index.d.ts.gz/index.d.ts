export declare const chownr: (p: string, uid: number, gid: number, cb: (er?: unknown) => any) => void;
export declare const chownrSync: (p: string, uid: number, gid: number) => void;
//# sourceMappingURL=index.d.ts.map