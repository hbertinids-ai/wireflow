export declare const constants: any;
//# sourceMappingURL=constants.d.ts.map