"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.rawPolyfilledDiagnosticRecord = void 0;
exports.rawPolyfilledDiagnosticRecord = {
    OPERATION: '',
    OPERATION_CODE: '0',
    CURRENT_SCHEMA: '/'
};
Object.freeze(exports.rawPolyfilledDiagnosticRecord);
