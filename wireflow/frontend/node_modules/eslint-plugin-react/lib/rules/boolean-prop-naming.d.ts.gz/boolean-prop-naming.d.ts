declare const _exports: import('eslint').Rule.RuleModule;
export = _exports;
//# sourceMappingURL=boolean-prop-naming.d.ts.map