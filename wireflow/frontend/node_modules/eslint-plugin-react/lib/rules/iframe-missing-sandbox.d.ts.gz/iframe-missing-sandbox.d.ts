declare const _exports: import('eslint').Rule.RuleModule;
export = _exports;
//# sourceMappingURL=iframe-missing-sandbox.d.ts.map