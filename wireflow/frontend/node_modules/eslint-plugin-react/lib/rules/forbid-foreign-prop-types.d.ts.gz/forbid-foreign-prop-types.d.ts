declare const _exports: import('eslint').Rule.RuleModule;
export = _exports;
//# sourceMappingURL=forbid-foreign-prop-types.d.ts.map