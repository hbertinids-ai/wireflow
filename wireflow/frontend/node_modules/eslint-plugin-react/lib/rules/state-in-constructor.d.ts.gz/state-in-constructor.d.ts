declare const _exports: import('eslint').Rule.RuleModule;
export = _exports;
//# sourceMappingURL=state-in-constructor.d.ts.map