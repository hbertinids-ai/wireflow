declare const _exports: import('eslint').Rule.RuleModule;
export = _exports;
//# sourceMappingURL=no-unused-prop-types.d.ts.map