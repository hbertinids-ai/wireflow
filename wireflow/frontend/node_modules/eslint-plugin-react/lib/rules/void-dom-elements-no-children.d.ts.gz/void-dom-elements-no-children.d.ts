declare const _exports: import('eslint').Rule.RuleModule;
export = _exports;
//# sourceMappingURL=void-dom-elements-no-children.d.ts.map