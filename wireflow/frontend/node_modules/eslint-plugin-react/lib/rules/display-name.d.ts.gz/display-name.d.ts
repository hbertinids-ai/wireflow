declare const _exports: import('eslint').Rule.RuleModule;
export = _exports;
//# sourceMappingURL=display-name.d.ts.map