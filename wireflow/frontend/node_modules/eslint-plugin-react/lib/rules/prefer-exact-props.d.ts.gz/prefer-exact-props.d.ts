declare const _exports: import('eslint').Rule.RuleModule;
export = _exports;
//# sourceMappingURL=prefer-exact-props.d.ts.map