declare const _exports: import('eslint').Rule.RuleModule;
export = _exports;
//# sourceMappingURL=forbid-elements.d.ts.map