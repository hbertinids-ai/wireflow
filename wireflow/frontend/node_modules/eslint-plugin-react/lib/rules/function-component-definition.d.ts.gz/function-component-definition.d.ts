declare const _exports: import('eslint').Rule.RuleModule;
export = _exports;
//# sourceMappingURL=function-component-definition.d.ts.map