declare function _exports(word: string): boolean;
export = _exports;
//# sourceMappingURL=isFirstLetterCapitalized.d.ts.map