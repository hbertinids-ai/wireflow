declare function _exports(methodName: string, shouldCheckUnsafeCb?: (context: import('eslint').Rule.RuleContext) => boolean): import('eslint').Rule.RuleModule;
export = _exports;
//# sourceMappingURL=makeNoMethodSetStateRule.d.ts.map