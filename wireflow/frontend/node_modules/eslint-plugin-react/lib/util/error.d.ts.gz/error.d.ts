export = error;
/**
 * Logs out a message if there is no format option set.
 * @param {string} message - Message to log.
 */
declare function error(message: string): void;
//# sourceMappingURL=error.d.ts.map