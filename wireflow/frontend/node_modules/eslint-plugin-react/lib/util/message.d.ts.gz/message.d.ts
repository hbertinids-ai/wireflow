declare function _exports(messageId: any, message: any): {
    messageId: any;
    message?: undefined;
} | {
    message: any;
    messageId?: undefined;
};
export = _exports;
//# sourceMappingURL=message.d.ts.map