declare function _exports(context: any, message: any, messageId: any, data: any): void;
export = _exports;
//# sourceMappingURL=report.d.ts.map