export function formatPropWrapperFunctions(propWrapperFunctions: any): string;
export function getExactPropWrapperFunctions(context: any): Set<any>;
export function getPropWrapperFunctions(context: any): Set<any>;
export function isExactPropWrapperFunction(context: any, name: any): any;
export function isPropWrapperFunction(context: any, name: any): any;
//# sourceMappingURL=propWrapper.d.ts.map