export function testReactVersion(context: any, semverRange: any): boolean;
export function testFlowVersion(context: any, semverRange: any): boolean;
export function resetWarningFlag(): void;
export function resetDetectedVersion(): void;
export function resetDefaultVersion(): void;
//# sourceMappingURL=version.d.ts.map