const jiti = require(".")();

jiti.register();
