import type { PluginObj } from "@babel/core";
export declare function TransformImportMetaPlugin(_ctx: any, opts: {
    filename?: string;
}): PluginObj;
