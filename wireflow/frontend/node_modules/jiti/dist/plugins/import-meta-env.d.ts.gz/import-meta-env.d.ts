/**
 * Forked from https://github.com/iendeavor/import-meta-env/tree/main/packages/babel 0.4.2 (MIT License - Copyright (c) 2021 Ernest)
 */
import type { PluginObj } from "@babel/core";
export declare function importMetaEnvPlugin({ template, types }: any): PluginObj;
