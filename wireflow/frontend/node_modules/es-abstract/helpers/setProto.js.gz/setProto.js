'use strict';

// TODO, semver-major: remove
module.exports = require('set-proto');
