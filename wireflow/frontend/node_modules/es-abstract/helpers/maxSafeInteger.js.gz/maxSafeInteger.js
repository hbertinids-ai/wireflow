'use strict';

// TODO, semver-major: delete
module.exports = require('math-intrinsics/constants/maxSafeInteger');
