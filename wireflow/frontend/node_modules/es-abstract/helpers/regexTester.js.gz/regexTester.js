'use strict';

// TODO: remove, semver-major

module.exports = require('safe-regex-test');
