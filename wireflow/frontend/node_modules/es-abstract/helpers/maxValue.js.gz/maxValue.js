'use strict';

module.exports = Number.MAX_VALUE || 1.7976931348623157e+308;
