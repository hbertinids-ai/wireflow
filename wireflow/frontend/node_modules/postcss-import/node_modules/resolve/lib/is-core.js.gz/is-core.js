var isCoreModule = require('is-core-module');

module.exports = function isCore(x) {
    return isCoreModule(x);
};
