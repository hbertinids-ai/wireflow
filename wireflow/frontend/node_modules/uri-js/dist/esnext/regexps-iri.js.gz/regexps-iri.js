import { buildExps } from "./regexps-uri";
export default buildExps(true);
//# sourceMappingURL=regexps-iri.js.map