import {
  require_react
} from "./chunk-I4MZPW7S.js";
export default require_react();
