import {
  require_react_dom
} from "./chunk-QXLG2TGQ.js";
import "./chunk-I4MZPW7S.js";
export default require_react_dom();
