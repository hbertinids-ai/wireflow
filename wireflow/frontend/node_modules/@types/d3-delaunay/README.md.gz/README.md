# Installation
> `npm install --save @types/d3-delaunay`

# Summary
This package contains type definitions for d3-delaunay (https://github.com/d3/d3-delaunay).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/d3-delaunay.

### Additional Details
 * Last updated: Tue, 07 Nov 2023 15:11:36 GMT
 * Dependencies: none

# Credits
These definitions were written by [Bradley Odell](https://github.com/BTOdell), and [Nathan Bierema](https://github.com/Methuselah96).
