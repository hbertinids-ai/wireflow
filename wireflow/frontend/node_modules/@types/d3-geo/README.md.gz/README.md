# Installation
> `npm install --save @types/d3-geo`

# Summary
This package contains type definitions for d3-geo (https://github.com/d3/d3-geo/).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/d3-geo.

### Additional Details
 * Last updated: Sun, 12 Nov 2023 19:07:04 GMT
 * Dependencies: [@types/geojson](https://npmjs.com/package/@types/geojson)

# Credits
These definitions were written by [Hugues Stefanski](https://github.com/ledragon), [Tom Wanzek](https://github.com/tomwanzek), [Alex Ford](https://github.com/gustavderdrache), [Boris Yankov](https://github.com/borisyankov), and [Nathan Bierema](https://github.com/Methuselah96).
