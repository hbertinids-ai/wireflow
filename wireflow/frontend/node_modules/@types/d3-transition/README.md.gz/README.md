# Installation
> `npm install --save @types/d3-transition`

# Summary
This package contains type definitions for d3-transition (https://github.com/d3/d3-transition/).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/d3-transition.

### Additional Details
 * Last updated: Mon, 07 Oct 2024 22:38:10 GMT
 * Dependencies: [@types/d3-selection](https://npmjs.com/package/@types/d3-selection)

# Credits
These definitions were written by [Tom Wanzek](https://github.com/tomwanzek), [Alex Ford](https://github.com/gustavderdrache), [Boris Yankov](https://github.com/borisyankov), [Robert Moura](https://github.com/robertmoura), and [Nathan Bierema](https://github.com/Methuselah96).
