# Installation
> `npm install --save @types/d3-scale`

# Summary
This package contains type definitions for d3-scale (https://github.com/d3/d3-scale/).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/d3-scale.

### Additional Details
 * Last updated: Wed, 05 Feb 2025 00:46:59 GMT
 * Dependencies: [@types/d3-time](https://npmjs.com/package/@types/d3-time)

# Credits
These definitions were written by [Tom Wanzek](https://github.com/tomwanzek), [Alex Ford](https://github.com/gustavderdrache), [Boris Yankov](https://github.com/borisyankov), [denisname](https://github.com/denisname), [rulonder](https://github.com/rulonder), and [Nathan Bierema](https://github.com/Methuselah96).
