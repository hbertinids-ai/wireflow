# Installation
> `npm install --save @types/d3-selection`

# Summary
This package contains type definitions for d3-selection (https://github.com/d3/d3-selection/).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/d3-selection.

### Additional Details
 * Last updated: Mon, 07 Oct 2024 22:38:10 GMT
 * Dependencies: none

# Credits
These definitions were written by [Tom Wanzek](https://github.com/tomwanzek), [Alex Ford](https://github.com/gustavderdrache), [Boris Yankov](https://github.com/borisyankov), [denisname](https://github.com/denisname), [Nathan Bierema](https://github.com/Methuselah96), and [Ambar Mutha](https://github.com/ambar-arkin).
