# Installation
> `npm install --save @types/d3-hierarchy`

# Summary
This package contains type definitions for d3-hierarchy (https://github.com/d3/d3-hierarchy/).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/d3-hierarchy.

### Additional Details
 * Last updated: Mon, 18 Mar 2024 18:36:06 GMT
 * Dependencies: none

# Credits
These definitions were written by [Tom Wanzek](https://github.com/tomwanzek), [Alex Ford](https://github.com/gustavderdrache), [Boris Yankov](https://github.com/borisyankov), [denisname](https://github.com/denisname), [Nathan Bierema](https://github.com/Methuselah96), and [Fil](https://github.com/Fil).
