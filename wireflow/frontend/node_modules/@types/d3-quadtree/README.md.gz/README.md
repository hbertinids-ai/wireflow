# Installation
> `npm install --save @types/d3-quadtree`

# Summary
This package contains type definitions for d3-quadtree (https://github.com/d3/d3-quadtree/).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/d3-quadtree.

### Additional Details
 * Last updated: Wed, 22 Nov 2023 00:24:48 GMT
 * Dependencies: none

# Credits
These definitions were written by [Tom Wanzek](https://github.com/tomwanzek), [Alex Ford](https://github.com/gustavderdrache), [Boris Yankov](https://github.com/borisyankov), [denisname](https://github.com/denisname), and [Nathan Bierema](https://github.com/Methuselah96).
