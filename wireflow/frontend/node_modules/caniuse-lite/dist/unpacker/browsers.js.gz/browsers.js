module.exports.browsers = require('../../data/browsers')
