export default function shallow<T, U>(objA: T, objB: U): boolean;
