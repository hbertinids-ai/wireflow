declare function hasNativeBigInts(): boolean;

export = hasNativeBigInts;