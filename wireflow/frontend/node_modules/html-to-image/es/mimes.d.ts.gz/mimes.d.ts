export declare function getMimeType(url: string): string;
