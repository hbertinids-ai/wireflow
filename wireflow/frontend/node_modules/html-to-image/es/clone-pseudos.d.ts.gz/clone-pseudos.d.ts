import type { Options } from './types';
export declare function clonePseudoElements<T extends HTMLElement>(nativeNode: T, clonedNode: T, options: Options): void;
