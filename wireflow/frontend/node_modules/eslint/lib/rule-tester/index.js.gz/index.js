"use strict";

module.exports = {
    RuleTester: require("./rule-tester")
};
