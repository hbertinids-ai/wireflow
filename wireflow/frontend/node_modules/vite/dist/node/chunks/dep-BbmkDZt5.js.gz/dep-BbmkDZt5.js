import "./dep-SmwnYDP9.js";
import { configDefaults, defineConfig, getDefaultEnvironmentOptions, isResolvedConfig, loadConfigFromFile, resolveBaseUrl, resolveConfig, resolveDevEnvironmentOptions, sortUserPlugins } from "./dep-Bm2ujbhY.js";

export { resolveConfig };