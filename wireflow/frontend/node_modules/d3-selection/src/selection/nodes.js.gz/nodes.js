export default function() {
  return Array.from(this);
}
