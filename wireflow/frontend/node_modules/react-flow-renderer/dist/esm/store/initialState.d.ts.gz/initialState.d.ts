import { CoordinateExtent, ReactFlowStore } from '../types';
export declare const infiniteExtent: CoordinateExtent;
declare const initialState: ReactFlowStore;
export default initialState;
