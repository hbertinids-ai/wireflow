import { FC, PropsWithChildren } from 'react';
declare const Wrapper: FC<PropsWithChildren<{}>>;
export default Wrapper;
