/// <reference types="react" />
declare function MinusIcon(): JSX.Element;
export default MinusIcon;
