/// <reference types="react" />
declare function LockIcon(): JSX.Element;
export default LockIcon;
