/// <reference types="react" />
declare function UnlockIcon(): JSX.Element;
export default UnlockIcon;
