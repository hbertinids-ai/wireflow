import { OnInit } from '../types';
declare function useOnInitHandler(onInit: OnInit<any> | undefined): void;
export default useOnInitHandler;
