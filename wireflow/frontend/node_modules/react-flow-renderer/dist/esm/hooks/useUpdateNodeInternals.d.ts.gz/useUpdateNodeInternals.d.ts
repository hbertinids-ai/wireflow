import { UpdateNodeInternals } from '../types';
declare function useUpdateNodeInternals(): UpdateNodeInternals;
export default useUpdateNodeInternals;
