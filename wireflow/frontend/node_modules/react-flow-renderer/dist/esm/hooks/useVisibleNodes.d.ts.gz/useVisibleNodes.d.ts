declare function useVisibleNodes(onlyRenderVisible: boolean): import("../types").Node<any>[];
export default useVisibleNodes;
