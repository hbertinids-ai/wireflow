import React from 'react';
import { NodeProps } from '../../types';
declare const _default: React.MemoExoticComponent<{
    ({ data, isConnectable, sourcePosition }: NodeProps<any>): JSX.Element;
    displayName: string;
}>;
export default _default;
