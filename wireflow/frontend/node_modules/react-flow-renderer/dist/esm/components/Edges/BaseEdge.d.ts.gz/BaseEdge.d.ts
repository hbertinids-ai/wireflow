/// <reference types="react" />
import { BaseEdgeProps } from '../../types';
declare const _default: ({ path, centerX, centerY, label, labelStyle, labelShowBg, labelBgStyle, labelBgPadding, labelBgBorderRadius, style, markerEnd, markerStart, }: BaseEdgeProps) => JSX.Element;
export default _default;
