import { Node } from '../types';
declare function useNodes<NodeData>(): Node<NodeData>[];
export default useNodes;
