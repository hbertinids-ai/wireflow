import { Edge } from '../types';
declare function useEdges<EdgeData>(): Edge<EdgeData>[];
export default useEdges;
