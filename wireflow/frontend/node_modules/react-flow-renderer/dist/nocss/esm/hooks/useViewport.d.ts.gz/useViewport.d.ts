import { Viewport } from '../types';
declare function useViewport(): Viewport;
export default useViewport;
