import React from 'react';
import { EdgeSmoothStepProps } from '../../types';
declare const _default: React.MemoExoticComponent<(props: EdgeSmoothStepProps) => JSX.Element>;
export default _default;
