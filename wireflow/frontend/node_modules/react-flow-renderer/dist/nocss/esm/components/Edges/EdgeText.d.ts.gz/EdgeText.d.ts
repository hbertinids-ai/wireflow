import React from 'react';
import { EdgeTextProps } from '../../types';
declare const _default: React.NamedExoticComponent<React.PropsWithChildren<EdgeTextProps>>;
export default _default;
