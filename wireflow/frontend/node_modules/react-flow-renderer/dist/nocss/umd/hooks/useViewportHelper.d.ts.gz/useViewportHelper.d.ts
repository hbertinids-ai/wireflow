import { ViewportHelperFunctions } from '../types';
declare const useViewportHelper: () => ViewportHelperFunctions;
export default useViewportHelper;
