import React from 'react';
interface MarkerDefinitionsProps {
    defaultColor: string;
    rfId?: string;
}
declare const _default: React.MemoExoticComponent<{
    ({ defaultColor, rfId }: MarkerDefinitionsProps): JSX.Element;
    displayName: string;
}>;
export default _default;
