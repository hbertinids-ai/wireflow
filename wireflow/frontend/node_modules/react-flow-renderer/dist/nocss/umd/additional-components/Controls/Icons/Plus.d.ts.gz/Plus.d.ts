/// <reference types="react" />
declare function PlusIcon(): JSX.Element;
export default PlusIcon;
