import React from 'react';
export declare const createGridLinesPath: (size: number, strokeWidth: number, stroke: string) => React.ReactElement;
export declare const createGridDotsPath: (size: number, fill: string) => React.ReactElement;
