declare const GroupNode: {
    (): null;
    displayName: string;
};
export default GroupNode;
