import { MutableRefObject } from 'react';
declare function useResizeHandler(rendererNode: MutableRefObject<HTMLDivElement | null>): void;
export default useResizeHandler;
