import React from 'react';
import { MiniMapProps } from '../../types';
declare const _default: React.MemoExoticComponent<{
    ({ style, className, nodeStrokeColor, nodeColor, nodeClassName, nodeBorderRadius, nodeStrokeWidth, maskColor, }: MiniMapProps<any>): JSX.Element;
    displayName: string;
}>;
export default _default;
