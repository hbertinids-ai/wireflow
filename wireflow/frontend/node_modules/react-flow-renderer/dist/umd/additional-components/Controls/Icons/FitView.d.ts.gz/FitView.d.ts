/// <reference types="react" />
declare function FitViewIcon(): JSX.Element;
export default FitViewIcon;
