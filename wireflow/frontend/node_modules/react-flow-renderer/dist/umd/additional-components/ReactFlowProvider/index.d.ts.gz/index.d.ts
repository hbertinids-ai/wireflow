import { FC, PropsWithChildren } from 'react';
declare const ReactFlowProvider: FC<PropsWithChildren<{}>>;
export default ReactFlowProvider;
