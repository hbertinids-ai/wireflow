import React from 'react';
import { BackgroundProps } from '../../types';
declare const _default: React.NamedExoticComponent<BackgroundProps>;
export default _default;
