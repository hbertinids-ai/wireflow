import React from 'react';
import { ReactFlowProps } from '../../types';
declare const ReactFlow: React.ForwardRefExoticComponent<ReactFlowProps & React.RefAttributes<HTMLDivElement>>;
export default ReactFlow;
