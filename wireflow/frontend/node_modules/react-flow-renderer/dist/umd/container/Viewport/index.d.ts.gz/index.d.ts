import { ReactNode } from 'react';
declare type ViewportProps = {
    children: ReactNode;
};
declare function Viewport({ children }: ViewportProps): JSX.Element;
export default Viewport;
