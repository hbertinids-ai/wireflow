import ES2015 from './es2015';

export = ES2015;
