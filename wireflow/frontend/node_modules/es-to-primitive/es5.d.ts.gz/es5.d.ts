declare function ToPrimitive(input: unknown, hint?: StringConstructor | NumberConstructor): null | undefined | string | symbol | number | boolean | bigint;

export = ToPrimitive;
