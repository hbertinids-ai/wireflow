export default x => () => x;
