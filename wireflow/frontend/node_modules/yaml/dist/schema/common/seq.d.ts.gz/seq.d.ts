import type { CollectionTag } from '../types';
export declare const seq: CollectionTag;
