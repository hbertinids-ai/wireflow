import type { ScalarTag } from '../types';
export declare const nullTag: ScalarTag & {
    test: RegExp;
};
