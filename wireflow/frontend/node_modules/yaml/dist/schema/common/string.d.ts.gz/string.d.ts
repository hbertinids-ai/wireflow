import type { ScalarTag } from '../types';
export declare const string: ScalarTag;
