export declare const schema: (import('../types').CollectionTag | import('../types').ScalarTag)[];
