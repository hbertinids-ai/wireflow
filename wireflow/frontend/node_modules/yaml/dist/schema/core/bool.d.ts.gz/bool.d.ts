import type { ScalarTag } from '../types';
export declare const boolTag: ScalarTag & {
    test: RegExp;
};
