import type { ScalarTag } from '../types';
export declare const trueTag: ScalarTag & {
    test: RegExp;
};
export declare const falseTag: ScalarTag & {
    test: RegExp;
};
