import type { ScalarTag } from '../types';
export declare const binary: ScalarTag;
