import type { ScalarTag } from '../types';
export declare const floatNaN: ScalarTag;
export declare const floatExp: ScalarTag;
export declare const float: ScalarTag;
