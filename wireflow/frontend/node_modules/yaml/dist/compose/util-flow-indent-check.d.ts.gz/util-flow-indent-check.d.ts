import type { Token } from '../parse/cst';
import type { ComposeErrorHandler } from './composer';
export declare function flowIndentCheck(indent: number, fc: Token | null | undefined, onError: ComposeErrorHandler): void;
