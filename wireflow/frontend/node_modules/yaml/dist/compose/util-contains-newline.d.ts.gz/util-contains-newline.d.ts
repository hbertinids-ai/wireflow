import type { Token } from '../parse/cst';
export declare function containsNewline(key: Token | null | undefined): boolean | null;
