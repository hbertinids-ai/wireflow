export declare function testEvents(src: string): {
    events: string[];
    error: unknown;
};
