export const radians = Math.PI / 180;
export const degrees = 180 / Math.PI;
