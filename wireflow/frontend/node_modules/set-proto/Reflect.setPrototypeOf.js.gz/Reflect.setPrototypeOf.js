'use strict';

/** @type {import('./Reflect.setPrototypeOf')} */
module.exports = (typeof Reflect !== 'undefined' && Reflect.setPrototypeOf) || null;
