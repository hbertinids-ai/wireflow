export declare const assertValidPattern: (pattern: any) => void;
//# sourceMappingURL=assert-valid-pattern.d.ts.map