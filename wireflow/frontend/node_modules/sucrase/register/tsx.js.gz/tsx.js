require("../dist/register").registerTSX();
