"use strict";Object.defineProperty(exports, "__esModule", {value: true}); class Transformer {
  // Return true if anything was processed, false otherwise.
  

  getPrefixCode() {
    return "";
  }

  getHoistedCode() {
    return "";
  }

  getSuffixCode() {
    return "";
  }
} exports.default = Transformer;
