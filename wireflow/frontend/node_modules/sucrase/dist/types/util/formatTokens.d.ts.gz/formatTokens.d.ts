import type { Token } from "../parser/tokenizer";
export default function formatTokens(code: string, tokens: Array<Token>): string;
