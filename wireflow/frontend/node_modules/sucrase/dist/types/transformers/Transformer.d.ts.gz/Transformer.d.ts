export default abstract class Transformer {
    abstract process(): boolean;
    getPrefixCode(): string;
    getHoistedCode(): string;
    getSuffixCode(): string;
}
