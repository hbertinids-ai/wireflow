/**
 * Common parser code for TypeScript and Flow.
 */
export declare function typedParseConditional(noIn: boolean): void;
export declare function typedParseParenItem(): void;
