export declare const READ_WORD_TREE: Int32Array;
