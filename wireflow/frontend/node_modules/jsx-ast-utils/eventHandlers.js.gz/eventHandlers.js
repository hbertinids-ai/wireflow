module.exports = require('./lib').eventHandlers; // eslint-disable-line import/no-unresolved
