"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = clone;
var _cloneNode = require("./cloneNode.js");
function clone(node) {
  return (0, _cloneNode.default)(node, false);
}

//# sourceMappingURL=clone.js.map
