{
  exports.getModuleName = () => require("@babel/helper-module-transforms").getModuleName;
}
0 && 0;

//# sourceMappingURL=babel-7-helpers.cjs.map
