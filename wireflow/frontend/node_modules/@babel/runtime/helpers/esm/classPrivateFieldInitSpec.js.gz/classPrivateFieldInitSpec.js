import checkPrivateRedeclaration from "./checkPrivateRedeclaration.js";
function _classPrivateFieldInitSpec(e, t, a) {
  checkPrivateRedeclaration(e, t), t.set(e, a);
}
export { _classPrivateFieldInitSpec as default };