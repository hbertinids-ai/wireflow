function _writeOnlyError(r) {
  throw new TypeError('"' + r + '" is write-only');
}
export { _writeOnlyError as default };