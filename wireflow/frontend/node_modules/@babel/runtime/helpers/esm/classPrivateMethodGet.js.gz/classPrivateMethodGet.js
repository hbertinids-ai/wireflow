import assertClassBrand from "./assertClassBrand.js";
function _classPrivateMethodGet(s, a, r) {
  return assertClassBrand(a, s), r;
}
export { _classPrivateMethodGet as default };