function _identity(t) {
  return t;
}
export { _identity as default };