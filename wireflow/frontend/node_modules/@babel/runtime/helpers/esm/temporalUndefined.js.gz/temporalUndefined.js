function _temporalUndefined() {}
export { _temporalUndefined as default };