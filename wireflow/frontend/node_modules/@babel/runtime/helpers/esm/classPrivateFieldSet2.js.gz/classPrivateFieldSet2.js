import assertClassBrand from "./assertClassBrand.js";
function _classPrivateFieldSet2(s, a, r) {
  return s.set(assertClassBrand(s, a), r), r;
}
export { _classPrivateFieldSet2 as default };