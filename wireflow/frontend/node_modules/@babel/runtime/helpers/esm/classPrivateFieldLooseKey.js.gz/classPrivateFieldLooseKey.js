var id = 0;
function _classPrivateFieldKey(e) {
  return "__private_" + id++ + "_" + e;
}
export { _classPrivateFieldKey as default };