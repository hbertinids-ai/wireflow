import classApplyDescriptorSet from "./classApplyDescriptorSet.js";
import classPrivateFieldGet2 from "./classPrivateFieldGet2.js";
function _classPrivateFieldSet(e, t, r) {
  var s = classPrivateFieldGet2(t, e);
  return classApplyDescriptorSet(e, s, r), r;
}
export { _classPrivateFieldSet as default };