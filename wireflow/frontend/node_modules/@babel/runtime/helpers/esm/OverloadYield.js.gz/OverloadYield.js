function _OverloadYield(e, d) {
  this.v = e, this.k = d;
}
export { _OverloadYield as default };