import assertClassBrand from "./assertClassBrand.js";
function _classStaticPrivateMethodGet(s, a, t) {
  return assertClassBrand(a, s), t;
}
export { _classStaticPrivateMethodGet as default };