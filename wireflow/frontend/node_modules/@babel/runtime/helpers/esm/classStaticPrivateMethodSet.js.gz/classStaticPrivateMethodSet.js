function _classStaticPrivateMethodSet() {
  throw new TypeError("attempted to set read only static private field");
}
export { _classStaticPrivateMethodSet as default };