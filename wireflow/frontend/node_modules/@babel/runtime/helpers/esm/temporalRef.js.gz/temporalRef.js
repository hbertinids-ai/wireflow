import temporalUndefined from "./temporalUndefined.js";
import tdz from "./tdz.js";
function _temporalRef(r, e) {
  return r === temporalUndefined ? tdz(e) : r;
}
export { _temporalRef as default };