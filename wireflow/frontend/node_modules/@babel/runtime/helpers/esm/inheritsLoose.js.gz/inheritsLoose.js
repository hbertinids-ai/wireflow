import setPrototypeOf from "./setPrototypeOf.js";
function _inheritsLoose(t, o) {
  t.prototype = Object.create(o.prototype), t.prototype.constructor = t, setPrototypeOf(t, o);
}
export { _inheritsLoose as default };