# @babel/helper-globals

> A collection of JavaScript globals for Babel internal usage

See our website [@babel/helper-globals](https://babeljs.io/docs/babel-helper-globals) for more information.

## Install

Using npm:

```sh
npm install --save @babel/helper-globals
```

or using yarn:

```sh
yarn add @babel/helper-globals
```
