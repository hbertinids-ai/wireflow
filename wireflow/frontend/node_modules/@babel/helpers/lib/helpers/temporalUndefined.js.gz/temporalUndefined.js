"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = _temporalUndefined;
function _temporalUndefined() {}

//# sourceMappingURL=temporalUndefined.js.map
