"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = _objectDestructuringEmpty;
function _objectDestructuringEmpty(obj) {
  if (obj == null) throw new TypeError("Cannot destructure " + obj);
}

//# sourceMappingURL=objectDestructuringEmpty.js.map
