"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = _getPrototypeOf;
function _getPrototypeOf(o) {
  exports.default = _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function _getPrototypeOf(o) {
    return o.__proto__ || Object.getPrototypeOf(o);
  };
  return _getPrototypeOf(o);
}

//# sourceMappingURL=getPrototypeOf.js.map
