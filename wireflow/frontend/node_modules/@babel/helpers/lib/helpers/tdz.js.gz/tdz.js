"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = _tdzError;
function _tdzError(name) {
  throw new ReferenceError(name + " is not defined - temporal dead zone");
}

//# sourceMappingURL=tdz.js.map
