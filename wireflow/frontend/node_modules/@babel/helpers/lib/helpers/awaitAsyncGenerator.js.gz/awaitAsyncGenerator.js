"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = _awaitAsyncGenerator;
var _OverloadYield = require("./OverloadYield.js");
function _awaitAsyncGenerator(value) {
  return new _OverloadYield.default(value, 0);
}

//# sourceMappingURL=awaitAsyncGenerator.js.map
