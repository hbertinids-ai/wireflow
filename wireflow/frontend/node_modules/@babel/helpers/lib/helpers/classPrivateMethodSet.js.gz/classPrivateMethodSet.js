"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = _classPrivateMethodSet;
function _classPrivateMethodSet() {
  throw new TypeError("attempted to reassign private method");
}

//# sourceMappingURL=classPrivateMethodSet.js.map
