"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = _classPrivateFieldGet2;
var _assertClassBrand = require("./assertClassBrand.js");
function _classPrivateFieldGet2(privateMap, receiver) {
  return privateMap.get((0, _assertClassBrand.default)(privateMap, receiver));
}

//# sourceMappingURL=classPrivateFieldGet2.js.map
