"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = _newArrowCheck;
function _newArrowCheck(innerThis, boundThis) {
  if (innerThis !== boundThis) {
    throw new TypeError("Cannot instantiate an arrow function");
  }
}

//# sourceMappingURL=newArrowCheck.js.map
