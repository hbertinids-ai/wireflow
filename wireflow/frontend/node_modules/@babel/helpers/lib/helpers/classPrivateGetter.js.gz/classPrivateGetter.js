"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = _classPrivateGetter;
var _assertClassBrand = require("./assertClassBrand.js");
function _classPrivateGetter(privateMap, receiver, getter) {
  return getter((0, _assertClassBrand.default)(privateMap, receiver));
}

//# sourceMappingURL=classPrivateGetter.js.map
