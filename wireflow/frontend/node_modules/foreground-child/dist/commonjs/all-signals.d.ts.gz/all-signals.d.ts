export declare const allSignals: NodeJS.Signals[];
//# sourceMappingURL=all-signals.d.ts.map