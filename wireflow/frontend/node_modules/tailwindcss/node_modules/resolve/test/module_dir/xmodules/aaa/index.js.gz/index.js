module.exports = function (x) { return x * 100; };
