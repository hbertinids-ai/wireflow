"use strict";
module.exports = postcssValueParser;
