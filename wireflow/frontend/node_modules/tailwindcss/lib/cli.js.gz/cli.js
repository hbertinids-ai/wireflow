#!/usr/bin/env node
"use strict";
module.exports = require("./cli/index");
