let defaultTheme = require('./lib/public/default-theme')
module.exports = (defaultTheme.__esModule ? defaultTheme : { default: defaultTheme }).default
