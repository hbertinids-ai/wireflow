/*
  @license
	Rollup.js v4.52.3
	Sat, 27 Sep 2025 07:05:38 GMT - commit 74c555c8e9ef7b62c2f57925bb2a5c0627ef8ae1

	https://github.com/rollup/rollup

	Released under the MIT License.
*/
import '../native.js';
export { parseAst, parseAstAsync } from './shared/parseAst.js';
import 'node:path';
