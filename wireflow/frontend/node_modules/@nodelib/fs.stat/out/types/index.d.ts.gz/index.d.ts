/// <reference types="node" />
import type * as fs from 'fs';
export declare type Stats = fs.Stats;
export declare type ErrnoException = NodeJS.ErrnoException;
