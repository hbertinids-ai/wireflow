/// <reference types="node" resolution-mode="require"/>
import * as util from 'util';
export declare const parseArgs: typeof util.parseArgs;
//# sourceMappingURL=parse-args.d.ts.map