'use strict';

module.exports = require('iterator.prototype');
