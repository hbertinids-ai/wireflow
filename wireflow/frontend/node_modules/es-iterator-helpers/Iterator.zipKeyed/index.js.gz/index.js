'use strict';

var getPolyfill = require('./polyfill');

module.exports = getPolyfill();
