import getAsyncFunction from './index.js';

/** @type {import('./index.d.mts').default} */
export default getAsyncFunction;
