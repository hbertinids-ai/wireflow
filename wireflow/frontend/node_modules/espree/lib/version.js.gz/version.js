const version = "9.6.1";

export default version;
